const express = require('express');
const router = express.Router();
const bookController = require('../controllers/bookController');
const { bookValidationRules, validate } = require('../middlewares/validateBook');

// Create a new book
router.post('/', bookValidationRules, validate, bookController.createBook);

// Get all books with pagination
router.get('/', bookController.getBooks);

// Get a single book by ID
router.get('/:id', bookController.getBookById);

// Update a book by ID
router.put('/:id', bookValidationRules, validate, bookController.updateBook);

// Delete a book by ID
router.delete('/:id', bookController.deleteBook);

module.exports = router; 