const express = require('express');
const dotenv = require('dotenv');
const connectDB = require('./config/db');
const booksRouter = require('./routes/books');
const errorHandler = require('./middlewares/errorHandler');

// Load environment variables from .env file
dotenv.config();

const app = express();

// Middleware to parse JSON
app.use(express.json());

// Connect to MongoDB
connectDB();

// Default root route
app.get('/', (req, res) => {
  res.send('Welcome to the Library Inventory API!');
});

// Set the port from environment or default to 3000
const PORT = process.env.PORT || 3000;

app.use('/api/books', booksRouter);
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
}); 